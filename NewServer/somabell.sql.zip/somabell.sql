-- phpMyAdmin SQL Dump
-- version 4.3.10
-- http://www.phpmyadmin.net
--
-- Host: localhost
-- 생성 시간: 15-06-22 12:15
-- 서버 버전: 5.5.41-MariaDB-1ubuntu0.14.04.1
-- PHP 버전: 5.5.9-1ubuntu4.9

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;

--
-- 데이터베이스: `somabell`
--

-- --------------------------------------------------------

--
-- 테이블 구조 `hyper_list`
--

CREATE TABLE IF NOT EXISTS `hyper_list` (
  `id` int(11) NOT NULL,
  `email` varchar(512) NOT NULL,
  `password` varchar(40) NOT NULL,
  `activate` int(11) NOT NULL,
  `name` text NOT NULL,
  `data` text NOT NULL
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

--
-- 테이블 구조 `store_beacon`
--

CREATE TABLE IF NOT EXISTS `store_beacon` (
  `id` int(11) NOT NULL,
  `owner` int(11) NOT NULL,
  `major` int(11) NOT NULL,
  `minor` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

--
-- 테이블 구조 `store_coupon`
--

CREATE TABLE IF NOT EXISTS `store_coupon` (
  `id` int(11) NOT NULL,
  `owner` int(11) NOT NULL,
  `target` int(11) NOT NULL,
  `title` text NOT NULL,
  `content` text NOT NULL,
  `end` int(11) NOT NULL,
  `data` text NOT NULL,
  `img` text NOT NULL,
  `price` int(11) NOT NULL,
  `disabled` int(11) NOT NULL
) ENGINE=InnoDB AUTO_INCREMENT=9 DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

--
-- 테이블 구조 `store_list`
--

CREATE TABLE IF NOT EXISTS `store_list` (
  `id` int(11) NOT NULL,
  `email` varchar(512) NOT NULL,
  `password` varchar(40) NOT NULL,
  `token` varchar(40) NOT NULL,
  `gcm` text NOT NULL,
  `activate` int(11) NOT NULL,
  `hyper` int(11) NOT NULL,
  `name` text NOT NULL,
  `location` text NOT NULL,
  `description` text NOT NULL,
  `data` text NOT NULL,
  `high` text NOT NULL
) ENGINE=InnoDB AUTO_INCREMENT=18 DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

--
-- 테이블 구조 `user_coupon`
--

CREATE TABLE IF NOT EXISTS `user_coupon` (
  `id` int(11) NOT NULL,
  `owner` int(11) NOT NULL,
  `coupon` int(11) NOT NULL,
  `used` int(11) NOT NULL,
  `start` int(11) NOT NULL,
  `end` int(11) NOT NULL
) ENGINE=InnoDB AUTO_INCREMENT=53 DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

--
-- 테이블 구조 `user_list`
--

CREATE TABLE IF NOT EXISTS `user_list` (
  `id` int(11) NOT NULL,
  `mdn` varchar(512) NOT NULL,
  `token` varchar(40) NOT NULL,
  `gcm` text NOT NULL,
  `data` text NOT NULL
) ENGINE=InnoDB AUTO_INCREMENT=5 DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

--
-- 테이블 구조 `user_ticket`
--

CREATE TABLE IF NOT EXISTS `user_ticket` (
  `id` int(11) NOT NULL,
  `owner` int(11) NOT NULL,
  `store` int(11) NOT NULL,
  `people` int(11) NOT NULL,
  `pivot` varchar(20) NOT NULL,
  `status` int(11) NOT NULL,
  `time` int(11) NOT NULL,
  `mdn` varchar(15) NOT NULL
) ENGINE=InnoDB AUTO_INCREMENT=187 DEFAULT CHARSET=utf8;

--
-- 덤프된 테이블의 인덱스
--

--
-- 테이블의 인덱스 `hyper_list`
--
ALTER TABLE `hyper_list`
  ADD PRIMARY KEY (`id`);

--
-- 테이블의 인덱스 `store_beacon`
--
ALTER TABLE `store_beacon`
  ADD PRIMARY KEY (`id`);

--
-- 테이블의 인덱스 `store_coupon`
--
ALTER TABLE `store_coupon`
  ADD PRIMARY KEY (`id`);

--
-- 테이블의 인덱스 `store_list`
--
ALTER TABLE `store_list`
  ADD PRIMARY KEY (`id`);

--
-- 테이블의 인덱스 `user_coupon`
--
ALTER TABLE `user_coupon`
  ADD PRIMARY KEY (`id`);

--
-- 테이블의 인덱스 `user_list`
--
ALTER TABLE `user_list`
  ADD PRIMARY KEY (`id`), ADD UNIQUE KEY `token_3` (`token`), ADD KEY `token` (`token`), ADD KEY `mdn` (`mdn`(255));

--
-- 테이블의 인덱스 `user_ticket`
--
ALTER TABLE `user_ticket`
  ADD PRIMARY KEY (`id`);

--
-- 덤프된 테이블의 AUTO_INCREMENT
--

--
-- 테이블의 AUTO_INCREMENT `hyper_list`
--
ALTER TABLE `hyper_list`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT,AUTO_INCREMENT=3;
--
-- 테이블의 AUTO_INCREMENT `store_beacon`
--
ALTER TABLE `store_beacon`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;
--
-- 테이블의 AUTO_INCREMENT `store_coupon`
--
ALTER TABLE `store_coupon`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT,AUTO_INCREMENT=9;
--
-- 테이블의 AUTO_INCREMENT `store_list`
--
ALTER TABLE `store_list`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT,AUTO_INCREMENT=18;
--
-- 테이블의 AUTO_INCREMENT `user_coupon`
--
ALTER TABLE `user_coupon`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT,AUTO_INCREMENT=53;
--
-- 테이블의 AUTO_INCREMENT `user_list`
--
ALTER TABLE `user_list`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT,AUTO_INCREMENT=5;
--
-- 테이블의 AUTO_INCREMENT `user_ticket`
--
ALTER TABLE `user_ticket`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT,AUTO_INCREMENT=187;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
